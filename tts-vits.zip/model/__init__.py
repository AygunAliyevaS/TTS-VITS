"""
VITS model package for Azerbaijani TTS.
"""

from model.vits import VITS 