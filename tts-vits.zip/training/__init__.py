"""
Training package for Azerbaijani TTS.
"""

from training.trainer import VITSTrainer 