"""
Text processing package for Azerbaijani TTS.
"""

from data.text.text_processor import TextProcessor
from data.text.az_symbols import AzerbaijaniPhonemes 